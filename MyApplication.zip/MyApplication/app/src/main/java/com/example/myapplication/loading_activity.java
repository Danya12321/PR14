package com.example.myapplication;

/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		loading
	 *	@date 		Wednesday 31st of May 2023 01:58:38 AM
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	


import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class loading_activity extends Activity {

	
	private View _bg__loading_ek2;
	private ImageView notch_ek1;
	private TextView ____time;
	private ImageView outline;
	private ImageView battery_end;
	private ImageView fill;
	private ImageView wifi;
	private ImageView icon___mobile_signal;
	private ImageView vector_2;
	private ImageView vector_1;
	private TextView sportlife;
	private TextView ___________;
	private View home_indicator;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.loading);

		
		_bg__loading_ek2 = (View) findViewById(R.id._bg__loading_ek2);
		notch_ek1 = (ImageView) findViewById(R.id.notch_ek1);
		____time = (TextView) findViewById(R.id.____time);
		outline = (ImageView) findViewById(R.id.outline);
		battery_end = (ImageView) findViewById(R.id.battery_end);
		fill = (ImageView) findViewById(R.id.fill);
		wifi = (ImageView) findViewById(R.id.wifi);
		icon___mobile_signal = (ImageView) findViewById(R.id.icon___mobile_signal);
		vector_2 = (ImageView) findViewById(R.id.vector_2);
		vector_1 = (ImageView) findViewById(R.id.vector_1);
		sportlife = (TextView) findViewById(R.id.sportlife);
		___________ = (TextView) findViewById(R.id.___________);
		home_indicator = (View) findViewById(R.id.home_indicator);
	
		
		//custom code goes here
	
	}
}
	
	